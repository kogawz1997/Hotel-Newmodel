# AI_MEMORY.md — Maitri PMS Project Memory

## Purpose

This file stores project context for Claude and other AI agents.

Update this when architectural decisions, repeated bugs, or important constraints appear.

---

## Known Project Identity

Maitri PMS is a Thai-market hotel PMS SaaS.

Important product promises:

- multi-tenant hotel SaaS
- staff dashboard
- guest portal
- public hotel pages
- direct booking engine
- AI inbox
- OTA/channel manager
- Omise/PromptPay payments
- e-tax
- TM30
- reporting
- team roles
- Vercel/Supabase deployment

---

## Known Technical Stack

- Next.js 15 App Router
- React 18
- TypeScript
- Supabase
- Tailwind CSS
- Claude AI SDK
- SendGrid
- Omise
- Sentry
- Vercel Cron
- Playwright / Node tests

---

## Repeated Risk Themes

### 1. Fake Completion

Some tasks may be marked complete in markdown but need code verification.

Claude must inspect actual implementation before trusting status docs.

### 2. Route Handler Return Types

Next.js App Router handlers must not return `null`.

Expected return:

- `Response`
- `NextResponse`
- `Promise<Response>`
- `Promise<NextResponse>`

### 3. Tenant Isolation

Every hotel/org data path must be scoped.

Raw ID queries are risky.

### 4. Auth Redirect Loops

Middleware and auth callbacks must be checked carefully.

Staff and guest auth flows must remain separate.

### 5. Deployment Drift

Vercel, package lock, Node version, env vars, and cron config can drift.

Validate with scripts rather than assuming.

---

## External Dependencies That Block Real Go-Live

- production Supabase configuration
- SendGrid sender/domain verification
- Omise live keys and webhooks
- optional Sentry DSN
- optional Upstash Redis
- real domain/DNS
- legal/compliance review for PDPA/TM30/e-tax text

---

## Preferred Claude Behavior

Claude should:

- read docs first
- inspect code next
- avoid blind rewrites
- classify fake-complete work
- prioritize P0/P1
- make small safe changes
- validate with scripts
- report risks honestly

---

## Update Rules

When a major issue is found, add:

```md
## YYYY-MM-DD — Issue Title

### Finding
What was found.

### Impact
Why it matters.

### Decision
What should be done.

### Files
Relevant files.
```

# MASTER_TASKS.md — Maitri PMS Claude Work Board

## Status Legend

- `[ ]` not started
- `[/]` partial
- `[x]` done and verified
- `[?]` needs inspection
- `[!]` blocked or risky

Completion labels:

- `DONE_REAL`
- `PARTIAL`
- `UI_ONLY`
- `BACKEND_ONLY`
- `FAKE_COMPLETE`
- `MISSING`
- `BLOCKED_EXTERNAL`

Claude must inspect actual code before changing status.

---

## P0 — Production Blockers

- [?] Verify current build passes on Node 20
- [?] Verify `npm ci` works with committed lockfile
- [?] Verify all API route handlers return `Response`/`NextResponse`, never `null`
- [?] Verify staff auth middleware has no redirect loop
- [?] Verify guest auth middleware is separate from staff auth
- [?] Verify tenant scoping on reservation APIs
- [?] Verify tenant scoping on payment/folio APIs
- [?] Verify `CRON_SECRET` protection on all cron routes
- [?] Verify Supabase service role is never exposed client-side
- [?] Verify required env vars are documented and checked

---

## P1 — Core PMS Completion

- [?] Reservation list and calendar use real data
- [?] Reservation create/edit/cancel has validation and tenant checks
- [?] Check-in/check-out workflow is wired to real reservation/room state
- [?] Room type management is wired to DB
- [?] Room status management is wired to DB
- [?] Housekeeping tasks are generated/managed correctly
- [?] Maintenance requests have real CRUD and status flow
- [?] Folio/payment records are linked correctly
- [?] Reports are hotel-scoped and date-filtered

---

## P1 — Guest Portal

- [?] Guest login/register/forgot password works
- [?] Guest account cannot access staff dashboard
- [?] Guest bookings are scoped to guest account
- [?] Cancellation reason flow is server-validated
- [?] Special requests update is server-validated
- [?] Verified-stay review checks ownership
- [?] Guest portal mobile layout works

---

## P1 — Booking Engine

- [?] Public hotel page loads real hotel profile
- [?] Gallery/branding uses real assets
- [?] Availability check uses real room/rate data
- [?] Pricing is server-calculated
- [?] Reservation creation is idempotent enough
- [?] Confirmation email handles failure safely
- [?] Payment path handles pending/failed/expired states
- [?] Mobile booking flow works

---

## P1 — Security and Tenant Isolation

- [?] All dashboard APIs validate staff role
- [?] All guest APIs validate guest ownership
- [?] Public APIs expose only public data
- [?] Payment webhooks validate provider data
- [?] Messaging webhooks validate signatures when available
- [?] RLS policies reviewed for critical tables
- [?] Audit logs exist for sensitive actions

---

## P2 — Integrations

- [?] LINE webhook receives and stores messages idempotently
- [?] WhatsApp webhook receives and stores messages idempotently
- [?] SendGrid email sending is configured and error-handled
- [?] OTA channel connections are hotel-scoped
- [?] OTA sync logs success/failure
- [?] AI reply generation uses hotel knowledge base
- [?] AI cost/check cron is safe
- [?] Omise/PromptPay flow is verified in test mode

---

## P2 — Operations

- [?] Sentry is configured for client/server/edge
- [?] Health check works
- [?] Smoke test covers core flows
- [?] Backup check exists and reports clearly
- [?] Go-live evidence script produces useful output
- [?] Deployment docs match actual repo state
- [?] Cron job outputs are observable

---

## P3 — UI/UX Polish

- [?] Dashboard has consistent page headers
- [?] Tables have loading/empty/error states
- [?] Forms have validation and submit states
- [?] Mobile dashboard navigation is usable
- [?] Guest portal feels like travel app quality
- [?] Public hotel page has SEO/OpenGraph
- [?] Design tokens/components are consistent

---

## Claude Audit Protocol

When asked to check progress:

1. inspect relevant files
2. classify each task
3. cite exact files/paths
4. separate real completion from fake completion
5. list highest ROI next fixes
6. do not update `[x]` unless validated

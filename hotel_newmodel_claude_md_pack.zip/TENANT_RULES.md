# TENANT_RULES.md — Multi-Tenant Isolation Rules

## Purpose

Maitri PMS is a SaaS for multiple organizations and hotels. Tenant isolation is the most important system rule.

A tenant leak is a production-level security failure.

---

## Tenant Concepts

Use actual schema names when confirmed, but expect these ownership layers:

- organization
- hotel
- staff user profile
- guest account
- reservation
- room
- payment
- invoice
- conversation
- integration connection

---

## Golden Rule

Every protected query must be scoped by tenant ownership.

Usually this means one or more of:

```txt
organization_id
hotel_id
user_id
guest_account_id
reservation_id + hotel ownership check
```

Never query by raw ID alone unless the resource is public by design.

Bad:

```ts
const reservation = await supabase
  .from("reservations")
  .select("*")
  .eq("id", reservationId)
  .single()
```

Better:

```ts
const reservation = await supabase
  .from("reservations")
  .select("*")
  .eq("id", reservationId)
  .eq("hotel_id", currentHotelId)
  .single()
```

Best: verify user membership/role first, then query scoped data.

---

## Staff Dashboard Rules

For `/dashboard/*`:

- require authenticated staff user
- load staff profile
- verify active organization membership
- verify hotel access
- enforce role permission
- scope all data by organization/hotel
- never rely only on hidden UI buttons

---

## Guest Portal Rules

For `/portal/*`:

- require guest auth
- guest account must not equal staff user profile
- guest can only access own bookings
- guest cannot access hotel dashboard APIs
- guest cancellation/modification must follow product policy
- verified stay review must prove reservation ownership

---

## Public Routes

For `/h/[slug]` and public booking:

Allowed:

- public hotel profile
- public room types
- public availability summaries
- public review aggregates
- public gallery

Forbidden:

- staff data
- private rates
- internal notes
- guest PII
- channel credentials
- payment secrets
- operational audit logs

---

## API Rules

Every protected API must check:

1. session exists
2. profile/account exists
3. organization/hotel membership exists
4. role permits action
5. target resource belongs to same tenant

If any check fails:

- return 401 for unauthenticated
- return 403 for unauthorized
- return 404 when hiding resource existence is safer
- never reveal cross-tenant resource details

---

## RLS Rules

Supabase RLS should follow:

- default deny
- explicit allow policies
- separate policies for select/insert/update/delete
- role-aware access when needed
- test with staff, guest, and anonymous paths

Never use service role as a shortcut for user-facing APIs unless the API performs explicit ownership checks.

---

## Integration Rules

Channel connections, webhook events, AI logs, payment records, and OTA sync logs must be hotel-scoped.

Every external event should resolve to a hotel safely:

- by configured channel connection
- by provider account ID
- by signed metadata
- by stored mapping

Never trust client-provided hotel ID without verification.

---

## Audit Log Rules

Important actions should write audit logs:

- reservation create/update/cancel
- check-in/check-out
- room status changes
- payment/refund
- invoice/e-tax issue
- team invite/role change
- settings change
- integration connect/disconnect

Audit logs must include:

- actor type
- actor ID
- organization/hotel ID
- action
- target resource
- timestamp
- safe metadata

---

## Claude Checklist

Before marking tenant-related work complete:

- [ ] all reads are scoped
- [ ] all writes are scoped
- [ ] APIs check membership
- [ ] APIs check role
- [ ] guest/staff auth separated
- [ ] public routes expose only public data
- [ ] tests or manual validation described
- [ ] no service role shortcut leaks data

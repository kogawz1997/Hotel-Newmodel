# ARCHITECTURE.md — Maitri PMS System Map

## Purpose

This file teaches Claude how to understand the Hotel-Newmodel repository before making changes.

Maitri PMS is a multi-tenant hotel SaaS with staff operations, guest portal, direct booking, AI inbox, payments, compliance, reporting, and integrations.

---

## Main Surfaces

### Staff Dashboard

Path:

```txt
/dashboard/*
```

Purpose:

- hotel operations
- reservations
- room management
- housekeeping
- maintenance
- reports
- guests
- payments/folios
- team management
- settings
- integrations
- AI inbox

Rules:

- must require staff auth
- must verify organization/hotel membership
- must enforce RBAC
- must never show data from another hotel

---

### Guest Portal

Path:

```txt
/portal/*
```

Purpose:

- guest login/register
- view bookings
- modify requests
- cancel booking if policy allows
- reviews
- account profile

Rules:

- guest account is separate from staff account
- guest can only access own reservations
- guest cannot access staff dashboard data
- cancellation/modification rules must be enforced server-side

---

### Public Hotel Page

Path:

```txt
/h/[slug]
```

Purpose:

- public hotel marketing page
- gallery
- rooms/rates
- reviews
- SEO/OpenGraph

Rules:

- public read-only data only
- no private hotel configuration
- no staff/guest personal data

---

### Booking Engine

Path:

```txt
/booking/[hotel]
```

Purpose:

5-step direct booking flow:

1. dates
2. room
3. guest info
4. review
5. confirmation

Rules:

- availability must come from real data
- rates must come from rate plans/calendar
- pricing must be calculated server-side
- reservation code must be generated safely
- email/payment flow must handle failure states

---

### API Route Handlers

Path:

```txt
/src/app/api/**/route.ts
```

Domains:

- reservations
- guests
- AI
- inbox/messages
- payments
- webhooks
- reports
- compliance
- invoices
- team
- cron
- public hotel
- booking

Rules:

- return `Response` or `NextResponse`
- never return `null`
- validate input
- validate auth when protected
- validate ownership
- return safe errors

---

## Data Model Mental Map

Expected core relations:

```txt
organizations
  └── hotels
        ├── room_types
        ├── rooms
        ├── rate_plans
        ├── rate_calendar
        ├── hotel_gallery
        ├── channel_connections
        ├── knowledge_base
        ├── reservations
        ├── housekeeping_tasks
        └── maintenance_requests

organizations
  └── user_profiles

reservations
  ├── guests
  ├── folio_items
  ├── payments
  ├── invoices
  └── booking_reviews

conversations
  └── messages
        └── ai_message_logs
```

Claude must confirm the actual schema from migrations/types before making database changes.

---

## Integration Architecture

### AI

Providers:

- Claude 3.5 Sonnet
- Claude Haiku for lightweight tasks where used

Use cases:

- guest message reply assist
- multilingual response
- sentiment analysis
- routing
- knowledge-base answers

Rules:

- never send secrets
- minimize sensitive guest data
- log AI usage/cost where available
- provide fallback when AI fails

---

### Messaging

Channels:

- LINE
- WhatsApp
- Email / SendGrid
- future OTA messaging

Rules:

- webhook signature validation where provider supports it
- normalize incoming messages
- idempotent processing
- log failures
- avoid duplicate messages

---

### Payments

Providers:

- Omise / PromptPay
- Stripe-ready architecture where applicable

Rules:

- never trust client amount
- calculate price server-side
- verify payment webhook
- idempotent payment handling
- support pending/failed/expired states
- link payment to reservation/folio/hotel

---

### Compliance

Domains:

- TM30
- e-Tax
- PDPA export/readiness

Rules:

- guest personal data must be protected
- exports must verify owner/requester
- compliance reports must be scoped by hotel
- logs must avoid unnecessary sensitive data

---

## Cron Architecture

Cron jobs are configured in `vercel.json`.

Typical domains:

- pre-arrival messages
- post-stay messages
- night audit
- TM30 reminder
- daily summary
- no-show handling
- trial expiration
- billing reconcile/retry
- reliability sweep
- abandoned booking recovery
- OTA sync/process
- pending booking expiration
- email reports
- AI cost checks
- backup checks

Rules:

- cron handlers must require `CRON_SECRET`
- cron must be idempotent
- cron must log result
- cron must be safe to run twice
- cron must handle partial failure
- cron must not leak tenant data

---

## Deployment Architecture

Primary target:

- Vercel
- Node.js 20.x
- Supabase
- optional Sentry
- optional Upstash Redis
- SendGrid
- Omise

Build path:

```txt
npm ci --no-audit --no-fund --progress=false
npm run build
```

Validation scripts exist in `package.json`. Use them instead of guessing.

---

## Architecture Change Rules

Before changing architecture:

1. inspect current folder structure
2. inspect existing patterns
3. avoid breaking route contracts
4. avoid breaking migrations
5. avoid moving files without updating imports
6. update docs
7. run validation scripts

Prefer small safe steps over heroic rewrites.

# SECURITY.md — Maitri PMS Security Rules

## Security Priority

This project handles hotel operations and guest data. Treat it as sensitive production software.

Data types may include:

- guest names
- contact info
- reservation history
- payment records
- invoices
- compliance reports
- staff accounts
- hotel settings
- channel tokens
- AI message content

---

## Secret Handling

Never expose:

- `SUPABASE_SERVICE_ROLE_KEY`
- `ANTHROPIC_API_KEY`
- `SENDGRID_API_KEY`
- `OMISE_SECRET_KEY`
- webhook secrets
- `CRON_SECRET`
- provider refresh/access tokens

Never put secrets in:

- client components
- `NEXT_PUBLIC_*`
- logs
- screenshots
- seed/demo output
- public docs

Only values that are safe for browser use should use `NEXT_PUBLIC_`.

---

## Auth Rules

Staff and guest auth must be separated.

Protected routes must verify auth server-side where possible.

Do not trust:

- hidden buttons
- client state
- query params
- localStorage
- unauthenticated cookies
- client-sent role names

---

## API Security

Every protected API must:

- validate method
- validate body
- validate session
- validate role
- validate ownership
- sanitize output
- return safe error messages

Never leak:

- stack traces
- SQL errors
- provider credentials
- internal environment details
- existence of cross-tenant resources

---

## Webhook Security

For provider webhooks:

- verify signatures where supported
- validate payload schema
- use idempotency keys/event IDs
- avoid duplicate processing
- log safely
- fail closed when verification fails

Webhooks should resolve the hotel/tenant from trusted provider mappings, not random request body fields.

---

## Payment Security

Payment rules:

- never trust client amount
- calculate totals server-side
- verify provider webhook
- store payment state transitions
- handle pending/failed/expired/refunded
- avoid duplicate confirmation
- ensure payment belongs to reservation/hotel

---

## AI Security

When calling Claude/AI providers:

- send minimum necessary context
- avoid unnecessary PII
- do not send secrets
- log request metadata safely
- handle provider failure
- do not allow prompt injection to override system/business rules

AI suggestions must not perform irreversible operations without server-side validation.

---

## File Upload Security

For images/assets:

- validate file type
- validate file size
- validate ownership
- use safe storage path
- avoid executable uploads
- avoid exposing private bucket URLs if not public

Hotel logos/galleries are public assets only after validation.

---

## PDPA / Privacy Rules

For guest data:

- collect only required data
- protect exports
- verify requester
- avoid over-sharing across staff roles
- log access to sensitive exports
- support deletion/export workflows where implemented

---

## Rate Limiting and Abuse

Consider rate limits for:

- login/signup
- password reset
- public booking
- AI reply generation
- webhooks
- contact forms
- payment creation
- guest registration

---

## Security Review Checklist

Before marking work done:

- [ ] no secrets exposed
- [ ] protected API checks auth
- [ ] protected API checks role
- [ ] protected API checks tenant ownership
- [ ] input validation exists
- [ ] errors are safe
- [ ] payment/webhook paths are idempotent
- [ ] service role use is justified
- [ ] public routes expose only public data

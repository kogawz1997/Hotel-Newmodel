# README_FOR_CLAUDE_PACK.md

## What This Pack Is

This is a Claude working-doc pack for `kogawz1997/Hotel-Newmodel`.

It is designed to make Claude behave like a careful engineering agent instead of a cheerful code generator with a chainsaw.

---

## Recommended Placement

Copy these files into the repo root:

```txt
/CLAUDE.md
/ARCHITECTURE.md
/TENANT_RULES.md
/SECURITY.md
/PRODUCT_RULES.md
/UI_SYSTEM.md
/DEPLOYMENT.md
/MASTER_TASKS.md
/AI_MEMORY.md
/GITHUB_WORKFLOW.md
/REVIEWER.md
```

Optional: move secondary docs into:

```txt
/docs/ai/
```

But keep `CLAUDE.md` at root.

---

## First Prompt To Use In Claude

```txt
Read CLAUDE.md first.

Then read:
- ARCHITECTURE.md
- TENANT_RULES.md
- SECURITY.md
- PRODUCT_RULES.md
- DEPLOYMENT.md
- MASTER_TASKS.md
- REVIEWER.md

After that, inspect the actual repository.

Your first task:
Audit the repo for production blockers, fake-complete features, tenant isolation risks, and build/deployment risks.

Do not edit code until you produce:
1. architecture summary
2. P0/P1 blockers
3. files inspected
4. proposed first implementation phase
```

---

## Implementation Prompt

```txt
Read all AI docs first.

Implement only P0 and P1 fixes from the approved plan.

Rules:
- keep changes small
- do not rewrite unrelated systems
- validate with type-check/build/tests where available
- report files changed
- report remaining risks
```

---

## Review Prompt

```txt
Use REVIEWER.md.

Inspect the repo and classify every claimed-complete feature as:
- DONE_REAL
- PARTIAL
- UI_ONLY
- BACKEND_ONLY
- FAKE_COMPLETE
- MISSING
- BLOCKED_EXTERNAL

Focus on actual code evidence, not markdown claims.
```

---

## Best Use

Use these docs for:

- Claude Code
- Claude Project Instructions
- GitHub-connected agent work
- production audit
- refactor guidance
- PR review
- SaaS readiness planning

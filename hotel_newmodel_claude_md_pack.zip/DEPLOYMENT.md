# DEPLOYMENT.md — Vercel / Supabase / Production Rules

## Runtime

Target runtime:

- Node.js 20.x
- Next.js 15
- Vercel
- Supabase
- optional Sentry
- optional Upstash Redis
- SendGrid
- Omise

---

## Install and Build

Vercel configuration expects:

```bash
npm ci --no-audit --no-fund --progress=false
npm run build
```

If `npm ci` fails, inspect:

- `package-lock.json`
- Node version
- dependency versions
- Vercel installCommand
- npm registry errors

Do not replace `npm ci` with `npm install` casually for production unless there is a documented reason.

---

## Validation Commands

Important scripts from `package.json` include:

```bash
npm run type-check
npm run lint
npm run build
npm run check
npm run check:env
npm run smoke
npm run release:check
npm run go-live:check
npm run health
npm run security-check
npm run reality:check
npm run final:verify
npm run verify:deploy
```

Use the strongest relevant validation command available.

Never claim validation passed without running it.

---

## Required Environment Variables

Core:

```env
NEXT_PUBLIC_APP_URL=
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
CRON_SECRET=
```

AI:

```env
ANTHROPIC_API_KEY=
```

Email:

```env
SENDGRID_API_KEY=
SENDGRID_FROM_EMAIL=
```

Payments:

```env
OMISE_PUBLIC_KEY=
OMISE_SECRET_KEY=
```

Messaging:

```env
LINE_CHANNEL_ACCESS_TOKEN=
LINE_CHANNEL_SECRET=
WHATSAPP_ACCESS_TOKEN=
```

Monitoring:

```env
SENTRY_DSN=
```

Only browser-safe values may use `NEXT_PUBLIC_`.

---

## Vercel Cron Rules

Cron paths must be protected by `CRON_SECRET`.

Cron handlers should:

- reject unauthorized requests
- be idempotent
- log start/end
- log processed counts
- handle partial failure
- avoid duplicate side effects
- return clear JSON result

Expected cron domains:

- pre-arrival
- post-stay
- night audit
- TM30 reminder
- daily summary
- no-show
- trial expiration
- billing reconcile/retry
- reliability sweep
- abandoned booking recovery
- OTA sync/process
- expire pending bookings
- email report
- AI cost check
- backup check

---

## Supabase Deployment Rules

Before production:

- apply migrations in correct order
- verify RLS policies
- verify storage bucket permissions
- verify auth redirect URLs
- verify service role exists only server-side
- verify seed/demo data does not pollute production

---

## Auth Redirect Rules

Check:

- production URL
- preview URL if used
- localhost URL for development
- email confirmation callback
- password reset callback
- guest portal callback
- staff dashboard callback

Avoid redirect loops in middleware.

---

## External Go-Live Dependencies

Before true go-live, verify:

- production Supabase project
- SendGrid verified sender/domain
- Omise live keys and webhook URL
- Sentry project configured
- optional Upstash Redis configured
- DNS/domain configured
- email templates configured
- legal/compliance text reviewed

---

## Deployment Risk Levels

### P0

- build fails
- migration breaks existing data
- auth unavailable
- payment confirmation broken
- tenant leak
- missing critical env vars

### P1

- cron failure
- email delivery failure
- OTA sync failure
- guest portal broken
- dashboard core flow broken

### P2

- report inaccuracy
- UI polish issues
- non-critical integration delay

---

## Claude Deployment Checklist

Before saying deploy is ready:

- [ ] `npm ci` works or lockfile issue documented
- [ ] `npm run type-check` passes
- [ ] `npm run build` passes
- [ ] env vars documented
- [ ] cron paths protected
- [ ] Supabase migrations considered
- [ ] auth redirects checked
- [ ] external providers checked
- [ ] rollback risk noted

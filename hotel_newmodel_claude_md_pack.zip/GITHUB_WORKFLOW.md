# GITHUB_WORKFLOW.md — Claude + GitHub Work Rules

## Purpose

This file defines how Claude should work with GitHub for Hotel-Newmodel.

---

## Default Workflow

For any code task:

1. inspect current branch
2. inspect relevant files
3. create a small plan
4. make focused changes
5. run validation
6. summarize changed files
7. identify risks
8. suggest next PR/task

---

## Branch Strategy

Use focused branch names:

```txt
fix/auth-callback-loop
fix/api-route-return-types
security/tenant-scope-reservations
feature/guest-booking-confirmation
refactor/reservation-service
docs/claude-md-system
```

---

## Commit Strategy

One commit should represent one logical change.

Good:

```txt
fix tenant scoping in reservation APIs
add mobile empty states to guest bookings
document cron secret requirements
```

Bad:

```txt
update
fix
done
final
```

---

## Pull Request Template

Claude should use this PR structure:

```md
## Summary

## What Changed

## Validation
- [ ] type-check
- [ ] lint
- [ ] build
- [ ] tests
- [ ] manual review

## Risk Level
P0 / P1 / P2 / P3

## Rollback Plan

## Notes
```

---

## Review Checklist

Before PR is considered safe:

- [ ] no secrets exposed
- [ ] no unrelated rewrites
- [ ] no tenant leaks
- [ ] route handlers return valid types
- [ ] role checks are server-side
- [ ] mobile behavior considered
- [ ] env vars documented if new
- [ ] migrations reviewed if any
- [ ] tests/validation included

---

## Issue Labels

Recommended labels:

```txt
p0-production-blocker
p1-core-flow
p2-integration
p3-polish
security
auth
tenant-isolation
booking-engine
guest-portal
dashboard
payments
cron
docs
fake-complete
needs-verification
```

---

## Claude GitHub Behavior

Claude must not:

- force push
- delete branches casually
- overwrite unrelated work
- close issues without evidence
- mark PR ready without validation
- claim tests passed if not run

Claude should:

- keep changes small
- explain risk
- write clear PR summaries
- ask for external credentials only when needed, but never request secrets in chat logs if avoidable

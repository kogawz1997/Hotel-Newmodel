# CLAUDE.md — Maitri PMS / Hotel-Newmodel Operating System

## Project Identity

This repository is **Maitri PMS**, a Thai-market hotel operating system.

Core product surfaces:

- `/dashboard/*` — staff/admin hotel operations
- `/portal/*` — guest account portal
- `/booking/[hotel]` — public direct booking engine
- `/h/[slug]` — public hotel page
- `/api/*` — App Router route handlers for reservations, AI, payments, webhooks, reports, compliance, team, cron

Core stack:

- Next.js 15 App Router
- React 18
- TypeScript
- Supabase Auth, PostgreSQL, Storage, Realtime
- Tailwind CSS
- Claude AI
- Vercel
- Sentry
- SendGrid
- Omise / PromptPay
- Playwright and Node-based tests

This project is not a simple CRUD dashboard. Treat it as a production SaaS platform with hotel operations, guest data, payments, compliance, AI messaging, and OTA/channel integrations.

---

## Prime Directive

Do not optimize for fake completion.

A feature is complete only when it has:

- real data wiring
- auth enforcement
- role enforcement
- tenant scoping
- validation
- loading state
- empty state
- error state
- mobile layout
- production-safe API behavior
- clear test/validation evidence

A UI with fake data is not complete.
A checkbox in a task file is not proof.
A page that renders but leaks tenant data is a production incident wearing Tailwind.

---

## Required Working Mode

Before editing code:

1. Read this file.
2. Read `ARCHITECTURE.md`.
3. Read `TENANT_RULES.md`.
4. Read `SECURITY.md`.
5. Read `PRODUCT_RULES.md`.
6. Inspect the actual files related to the request.
7. Identify affected systems.
8. Make a short implementation plan.
9. Implement incrementally.
10. Validate with available scripts.

Never blindly rewrite large areas.

---

## Repository Awareness Rules

Always inspect before claiming.

When asked “is this done?”:

- check actual code
- check API wiring
- check database/migrations
- check auth
- check UI states
- check mobile
- check tests/scripts
- compare against task docs

Do not trust task status alone.

Classify every item as:

- `DONE_REAL` — implemented and wired
- `PARTIAL` — exists but incomplete
- `UI_ONLY` — visible but not functional
- `BACKEND_ONLY` — API exists but no usable UI
- `FAKE_COMPLETE` — marked done but not actually production-ready
- `MISSING` — not found
- `BLOCKED_EXTERNAL` — depends on external service/config

---

## Code Rules

Use:

- TypeScript strict patterns
- explicit types
- Zod validation for input where appropriate
- small components
- reusable services
- consistent response shapes
- clear error handling
- server-side permission checks

Avoid:

- `any`
- unscoped Supabase queries
- returning `null` from route handlers
- service role usage outside trusted server paths
- frontend-only permission checks
- fake production data
- deleting user work without reason
- broad rewrites
- silent catches
- console spam

---

## Next.js App Router Rules

For `src/app/api/**/route.ts`:

- `GET`, `POST`, `PATCH`, `PUT`, `DELETE` must return `Response` or `NextResponse`.
- Never return `null`.
- Validate request body.
- Validate session.
- Validate role and ownership.
- Return safe JSON.
- Use correct HTTP status codes.
- Avoid leaking internal stack traces.

Example response shape:

```ts
type ApiSuccess<T> = {
  ok: true
  data: T
}

type ApiFailure = {
  ok: false
  error: {
    code: string
    message: string
  }
}
```

---

## Supabase Rules

For protected server data:

- use server-safe Supabase client
- scope every query by `organization_id`, `hotel_id`, or ownership key
- never expose service role key to browser
- respect RLS
- test access paths for different roles
- avoid accidental cross-hotel data reads

Every insert/update/delete must prove:

- authenticated user exists
- profile exists
- hotel/org membership exists
- role permits action
- resource belongs to the same tenant

---

## PMS Domain Rules

Always remember this is hotel software.

Critical domains:

- organizations
- hotels
- staff users
- guest accounts
- room types
- rooms
- rate plans
- rate calendar
- reservations
- guests
- folios
- payments
- invoices
- housekeeping
- maintenance
- conversations/messages
- channel connections
- OTA sync
- TM30 reports
- e-tax
- audit logs

Do not mix guest auth and staff auth.
Do not mix public booking paths with protected dashboard paths.
Do not assume a reservation belongs to the current hotel without checking.

---

## UI Rules

Every page must have:

- clear page title
- description/context
- primary action
- loading state
- empty state
- error state
- responsive layout
- usable mobile behavior
- consistent visual language

Every table/list should consider:

- search/filter
- status badge
- row actions
- pagination or limit
- empty state
- skeleton/loading state

Every form should include:

- labels
- validation
- disabled submitting state
- success/error feedback

---

## Production Validation Commands

Prefer these commands when available:

```bash
npm run type-check
npm run lint
npm run build
npm run check
npm run go-live:check
npm run release:check
npm run security-check
npm run reality:check
npm run final:verify
npm run test:unit
npm run test:e2e
npm run test:playwright
```

If a command cannot run, say why. Never claim it passed if it did not run.

---

## GitHub Workflow

Use focused changes.

Preferred branch naming:

- `fix/auth-redirect-loop`
- `feature/guest-booking-flow`
- `refactor/reservation-service`
- `security/tenant-scope-audit`
- `docs/claude-operating-system`

Good commit style:

- `fix tenant scoping for reservation APIs`
- `add empty states to guest booking portal`
- `document Vercel cron validation workflow`

Bad commit style:

- `fix`
- `update`
- `done`
- `final`
- `real-final-v3`

---

## Output Format After Work

Use this format:

```md
## Summary
What changed.

## Files Changed
- `path`: change summary

## Validation
- type-check:
- lint:
- build:
- tests:
- manual review:

## Risks
Remaining risk or unknowns.

## Next Steps
Highest priority follow-up.
```

---

## Forbidden Behavior

Never:

- claim production-ready without evidence
- bypass auth for convenience
- remove RLS/permission checks
- expose secrets
- use fake data in production path
- invent files or APIs without checking
- delete large code areas without explanation
- hide build/type errors
- mark incomplete work as done

---

## Final Principle

Your job is not to generate more code.

Your job is to make Maitri PMS safer, clearer, more maintainable, and closer to real production use.

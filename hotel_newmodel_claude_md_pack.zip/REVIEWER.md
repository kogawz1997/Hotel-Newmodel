# REVIEWER.md — Production Audit Skill

## Purpose

Use this file when Claude is asked to review the repo, check completion, or find missing production work.

---

## Audit Categories

Score each 0-100:

- Auth
- RBAC
- Tenant isolation
- Database/schema
- API correctness
- Staff dashboard
- Guest portal
- Booking engine
- Payments
- OTA/integrations
- AI inbox
- Compliance
- UI/UX
- Mobile
- Observability
- Deployment
- Tests
- Documentation

---

## Finding Severity

### P0

Production/security blocker.

Examples:

- tenant data leak
- auth bypass
- build fails
- payment confirmation broken
- exposed secret

### P1

Major feature broken.

Examples:

- reservation creation fails
- guest portal inaccessible
- check-in flow broken
- cron mutates wrong data

### P2

Important improvement.

Examples:

- missing empty states
- weak validation
- incomplete logs
- mobile table awkward

### P3

Polish or cleanup.

Examples:

- copywriting
- spacing
- small refactor
- docs refinement

---

## Fake-Complete Detection

For every feature, check:

- Is there UI?
- Is there API?
- Is there database support?
- Is it wired to real data?
- Is auth checked?
- Is role checked?
- Is tenant ownership checked?
- Are loading/empty/error states present?
- Is mobile usable?
- Is it tested or manually verified?

If not, do not mark done.

---

## Review Output Format

```md
## Executive Summary

## Scores

| Area | Score | Notes |
|---|---:|---|

## P0 Blockers

## P1 Major Issues

## Fake-Complete Items

## Highest ROI Fixes

## Files Inspected

## Recommended Next Phase
```

---

## Evidence Rule

Every finding should cite a file path when possible.

Do not say “probably” unless clearly marked as an assumption.

# UI_SYSTEM.md — Maitri PMS Design System Rules

## Design Goal

Maitri PMS should feel like a premium hotel operating system:

- calm
- clear
- fast
- trustworthy
- modern
- practical
- mobile usable

Not every page needs fireworks. Most hotel staff want speed, clarity, and not having to guess where the cancel button went because a designer discovered gradients.

---

## Core UI Principles

Every screen must answer:

1. What is this page?
2. What is the current status?
3. What can the user do next?
4. What requires attention?
5. What happened after an action?

---

## Layout Rules

Use consistent:

- page header
- section spacing
- cards
- filters
- tables
- forms
- action bars
- modals
- status badges

Avoid:

- random card sizes
- dense walls of text
- unaligned controls
- inconsistent buttons
- dashboard pages with no primary action

---

## Page Header Pattern

Recommended:

```txt
Title
Short description
Primary action
Secondary actions / filters
```

Example:

```txt
Reservations
Manage bookings, check-ins, cancellations, and guest stay status.
[New Reservation] [Export] [Filter]
```

---

## Data Cards

Use for summaries:

- occupancy
- arrivals today
- departures today
- pending payments
- dirty rooms
- open maintenance
- unread messages

Rules:

- short label
- clear value
- status/trend if useful
- link to related page when useful

---

## Tables

Tables should include:

- meaningful columns
- status badges
- row actions
- loading skeleton
- empty state
- pagination/limit for large datasets
- mobile alternative when table is too wide

Avoid horizontal-scroll disasters on phones.

---

## Forms

Forms must include:

- labels
- validation
- clear errors
- disabled submitting state
- success feedback
- cancel/back action
- sensible grouping

For destructive actions:

- confirmation modal
- clear consequence
- permission check

---

## Status Badges

Use consistent badge language.

Reservations:

- Pending
- Confirmed
- Checked in
- Checked out
- Cancelled
- No-show
- Expired

Rooms:

- Clean
- Dirty
- Occupied
- Out of order
- Maintenance

Payments:

- Pending
- Paid
- Failed
- Expired
- Refunded

---

## Empty States

Every empty state should include:

- short explanation
- next action
- optional setup hint

Bad:

```txt
No data
```

Better:

```txt
No reservations yet.
Create your first reservation or connect an OTA channel to start receiving bookings.
```

---

## Error States

User-facing errors should be:

- short
- human
- actionable
- not stack traces

Example:

```txt
Could not load reservations.
Check your connection and try again.
```

---

## Loading States

Use:

- skeleton for page/table/card loading
- disabled states for submit buttons
- subtle loading indicators for inline actions

Avoid layout jumping.

---

## Mobile Rules

All key flows must work on:

- iPhone-sized screens
- Android phones
- tablets
- desktop

Check:

- navigation
- sticky headers
- forms
- modals
- date pickers
- tables
- action buttons
- keyboard overlap

If a hotel manager cannot check bookings on a phone, the product is not actually useful.

---

## Guest Portal Style

Guest-facing UI should feel more polished and travel-app-like:

- larger imagery
- clearer booking cards
- simple actions
- friendly language
- strong mobile layout
- minimal admin complexity

---

## Staff Dashboard Style

Staff-facing UI should favor:

- density
- speed
- clarity
- filters
- operational status
- quick actions
- fewer animations

---

## Accessibility

Minimum rules:

- buttons have accessible labels
- inputs have labels
- contrast is readable
- focus states are visible
- icons are not the only indicator
- forms are keyboard usable

---

## Claude Checklist

Before marking UI complete:

- [ ] desktop layout works
- [ ] mobile layout works
- [ ] loading state exists
- [ ] empty state exists
- [ ] error state exists
- [ ] primary action is clear
- [ ] destructive actions are confirmed
- [ ] visual style matches nearby pages

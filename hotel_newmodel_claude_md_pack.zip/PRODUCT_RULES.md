# PRODUCT_RULES.md — Hotel PMS Domain Rules

## Product Goal

Maitri PMS is a hotel operating system for Thai hotels.

It should support:

- hotel staff operations
- direct booking
- guest portal
- AI-assisted inbox
- OTA/channel manager
- payments
- e-tax
- TM30
- reporting
- housekeeping
- maintenance
- team management

---

## User Types

### Staff Users

Examples:

- owner
- admin
- manager
- front desk
- housekeeping
- maintenance
- accounting
- marketing
- support
- viewer

Staff users operate `/dashboard/*`.

### Guest Users

Guests operate `/portal/*`.

Guest accounts are not staff accounts.

### Public Visitors

Anonymous visitors can access public hotel pages and booking engine.

---

## Reservation Lifecycle

Recommended statuses:

```txt
pending
confirmed
checked_in
checked_out
cancelled
no_show
expired
```

Rules:

- pending booking may expire if not paid/confirmed
- confirmed booking can check in
- checked-in booking can check out
- checked-out booking can be reviewed by verified guest
- cancelled/no-show should not be treated as active occupancy
- financial records must remain auditable after cancellation

---

## Booking Engine Rules

The public booking engine should:

1. select dates
2. select room/rate
3. collect guest data
4. review price/policies
5. confirm booking/payment

Must use real data:

- hotel availability
- room types
- rate plans
- rate calendar
- taxes/VAT
- booking policies

Do not hardcode prices in UI.

---

## Pricing Rules

Pricing must be server-calculated.

Consider:

- nightly rate
- date range
- room type
- rate plan
- occupancy/adult/child count
- discounts/promotions
- taxes/VAT
- fees
- payment method state

Never trust client-calculated final total.

---

## Check-In / Check-Out

Check-in should verify:

- reservation exists
- correct hotel
- allowed status
- guest identity requirements if implemented
- room assignment
- payment/folio condition if required by policy

Check-out should verify:

- active stay
- folio balance
- housekeeping task creation if implemented
- invoice/e-tax flow if applicable

---

## Housekeeping Rules

Housekeeping statuses may include:

```txt
clean
dirty
inspected
out_of_order
maintenance
```

After checkout:

- room should become dirty or pending housekeeping
- housekeeping task may be created
- room should not be sold as clean until completed

---

## Maintenance Rules

Maintenance requests should track:

- hotel
- room if applicable
- priority
- status
- assigned staff
- description
- resolution notes
- timestamps

---

## AI Inbox Rules

AI can assist, not blindly control.

AI reply suggestions must:

- use hotel knowledge base
- respect tone/language
- avoid unsupported promises
- avoid giving payment/legal guarantees
- allow staff review where needed
- log usage and result where available

---

## OTA / Channel Rules

OTA sync must be:

- idempotent
- conflict-aware
- logged
- retry-safe
- hotel-scoped

Potential conflicts:

- double booking
- rate mismatch
- inventory mismatch
- cancellation mismatch
- webhook retry duplicate

---

## Payments and Folio

Payment records should link to:

- hotel
- reservation
- guest/folio
- provider reference
- amount
- currency
- status
- timestamps

Folio should preserve financial history.

Do not delete payment history casually.

---

## Compliance

Thai-market concerns:

- TM30
- e-tax invoice
- PDPA readiness
- audit logs

Compliance features must prefer accuracy and traceability over pretty UI.

---

## Reporting

Core metrics:

- occupancy
- ADR
- RevPAR
- revenue by channel
- reservations by status
- cancellations/no-show
- housekeeping status
- payment state
- TM30 compliance

Reports must be scoped by hotel and date range.

---

## Completion Definition

A product feature is complete only when:

- UI exists
- backend exists
- database/schema exists if needed
- auth/role/tenant checks exist
- real data is used
- error/empty/loading states exist
- mobile layout is usable
- validation/testing evidence is provided
